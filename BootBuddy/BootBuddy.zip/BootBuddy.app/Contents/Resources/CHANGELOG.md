### 1.0.1

- Project renamed from `DarkBoot` to `Boot Buddy`
- Notarized for macOS 10.15+
- Universal binary for M1 Macs
- UI adjustments for macOS 11
- Descriptions added for all boot options
- Fix setting login screen on 10.14+
- Fix displaying incorrect custom color
- Fix setting some poot options
- Fix Boot sound options on new Macs
- Removed osxinj
- Removed AMFI boot option
- Removed option to set lock screen text
- Removed option to set boot image
- Lock screen settings require [MacForge](https://www.macenhance.com/)
- Bug fixes
