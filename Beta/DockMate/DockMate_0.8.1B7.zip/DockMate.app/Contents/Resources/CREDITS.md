### Resources

- Analytics : [appcenter-sdk-apple](https://www.github.com/microsoft/appcenter-sdk-apple)
- Updates : [Sparkle](https://www.github.com/sparkle-project/Sparkle)
- Purchases and Licensing : [Paddle](https://www.github.com/PaddleHQ/Mac-Framework-V4)
- Startup : [NSBundle-LoginItem](https://github.com/nklizhe/NSBundle-LoginItem)
- Move to /Apps : [LetsMove](https://www.github.com/potionfactory/LetsMove)

### Developement

- [macEnhance](https://www.macenhance.com/)
