### Resources

- Code Injection : [mach_inject](https://www.github.com/rentzsch/mach_inject)
- Analytics : [appcenter-sdk-apple](https://www.github.com/microsoft/appcenter-sdk-apple)
- Updates : [Sparkle](https://www.github.com/sparkle-project/Sparkle)
- Purchases and Licensing : [Paddle](https://www.github.com/PaddleHQ/Mac-Framework-V4)
- Startup : [StartAtLoginController](https://www.github.com/alexzielenski/StartAtLoginController)
- Folder moitoring : [DirectoryWatchdog](https://www.github.com/graetzer/DirectoryWatchdog)
- Auto move : [LetsMove](https://www.github.com/potionfactory/LetsMove)
- Privledged scripts : [STPrivilegedTask](https://www.github.com/sveinbjornt/STPrivilegedTask)
- Cached web images : [SDWebImage](https://www.github.com/SDWebImage/SDWebImage)

### Lead Developer

- [Wolfgang Baird](https://github.com/w0lfschild) ([w0lfschild](https://github.com/w0lfschild)) ([MacEnhance](https://www.macenhance.com/))
- [jslegendre](https://github.com/jslegendre)

### Contributors

- [nypl](https://github.com/nypl)


