# Warning

### Adjusting the lcokscreen requires code injection. 
### In order to use this feature you must install and setup the application [MacForge](https://www.macenhance.com/).
### System Integrity Protection must be partly disabled for the feature to work

## You can get MacForge here: [Download](https://github.com/w0lfschild/app_updates/raw/master/MacForge/MacForge.zip)
