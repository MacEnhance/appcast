### Resources

- Analytics : [appcenter-sdk-apple](https://www.github.com/microsoft/appcenter-sdk-apple)
- Auto move : [LetsMove](https://www.github.com/potionfactory/LetsMove)
- Folder monitoring : [SGDirWatchdog](https://github.com/graetzer/DirectoryWatchdog)
- Icon : [Davi Andrade](http://www.daviandrade.com/)
- Sales & Licenses : [Paddle](https://paddle.com/)
- Updates : [Sparkle](https://www.github.com/sparkle-project/Sparkle)

### Developerment

- MacEnhance ([GitHub](https://github.com/MacEnhance)) ([Website](https://www.macenhance.com/))
- Wolfgang Baird ([GitHub](https://github.com/w0lfschild))
- Jeremy Legendre ([GitHub](https://github.com/jslegendre))
