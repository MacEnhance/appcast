# About themes

- Themes are simply a collection of image files that will apply to specific items
- A themes is a folder with the extension `.ict` which contains appropreatley named image files

## Creating a theme

- Click the plus (+) icon at the top of the folder theme list table
- Rename the theme by slecting the title
- Drag images (`.png` or `.jpg`) into the collection view next to the list of themes.
- Secect the items you want the images to apply to by mousing over the image and clicking the link (🔗) icon

## Modifying a theme in IconChamp

- Theme names can be modified by clicking their title in the theme list
- Icons can be added by dragging from Finder into the theme icon grid
- Icons can be can be removed by mousing over the image and clicking the (🅧) icon
- Icons be set to another app, folder, extension or drive by mousing over the image and clicking the link (🔗) icon

## Locating a theme

- To reveal a theme in Finder select the theme in the folder theme list table and click the magnifying glass (🔍) icon

## Adding a theme to IconChamp

- Simply drag a theme into the theme list of IconChamp 
- Or double click a theme in Finder

## Removing a theme

- Select the theme in the theme list
- Click the trash can icon at the top of the folder theme list table

