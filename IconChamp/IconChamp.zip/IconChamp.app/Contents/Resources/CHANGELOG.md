### 1.0.1

- Initial release

### 0.5.5

- Safari app can now be themed with SIP enabled
- Reverted system version requirement
- Don't show what's new window until a new version shows up
- Updated bug report url
- Support for adding folders with a custom image to themes
- Fix apps occasionally showing twice
- Minor adjustments

### 0.5.3

- Now copies `.ict` bundles to themes folder when opened from Finder

### 0.5.2

- New changelog window shown on app update
- Fix automatic re-theme after app updates (currently only applies to `/Applications`)
- Fix 3rd party dock icons not updating
- Fix typo

### 0.5.1

- Fix typo in helper installation window
- Fix license activation not working

### 0.5.0

- initial beta release
