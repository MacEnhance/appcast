### 1.3.5

- Improved support for macOS Ventura and Sonoma
- Add support for theming icons in System Settings
- Fix alias indicators not showing for themed system icons
- Improve theme persistence between restarts and OS updates
- Add "Force Re-Apply Icon" option to right-click menu
- Ensure correct icon is generated for current appearance
- Bug fixes and enhancements

### 0.5.5

- Safari app can now be themed with SIP enabled
- Reverted system version requirement
- Don't show what's new window until a new version shows up
- Updated bug report url
- Support for adding folders with a custom image to themes
- Fix apps occasionally showing twice
- Minor adjustments

### 0.5.3

- Now copies `.ict` bundles to themes folder when opened from Finder

### 0.5.2

- New changelog window shown on app update
- Fix automatic re-theme after app updates (currently only applies to `/Applications`)
- Fix 3rd party dock icons not updating
- Fix typo

### 0.5.1

- Fix typo in helper installation window
- Fix license activation not working

### 0.5.0

- initial beta release
