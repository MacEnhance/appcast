## IconChamp

### TODO Code

    - Add apps outside of /Applications
    - Add view when visiting the themes tab when there are no themes present
    - Fix the icon for the Search folder is inside the extensions tab instead of the system folders tab
    - Fix the icon for executable files is inside the system folders tab instead of the extensions tab
    - Update theme item count when items are added or removed
    - Improve selecting / editing a theme name
    - Add option to force reset icon in case something breaks
    - Fix clicking reset caches in preferences breaks icon images
    - Add minimum display time for the progress bar when applying changes
    - Add item info to progress bar when resetting/restoring
    - Themes should have an optional `.plist` with some info : author, contact, etc
    - Accounts using FireBase
    - Theme store 
    
### TODO Not code
    
    - Create a basic walkthough video of how to use the app
    - Create some screenshots / promotional images

### DONE
- The bottom text is not accurate, clicking apply in all views restarts both the Dock and Finder
- Better application icon
- Implement Disks/Drives view
- Clicking the reset icon button should just queue the item to be reset, not actually reset it
- Fix icons using the old image after changes are made in some cases.
- Hook up all buttons
- ICIconView should be changed to an NSView and have some more collection specific actions
- Implement removing extensions from preferences
- Fix system extensions
- Add progress bar for applying anything other than individual icon
- Impelemt button to show, add and delete themes
- Implement Extensions tab preferences
- Implement User Folders tab and preferences
- Implement System Folders tab
- Make sure all bottom bar buttons are hooked up properly
- Manually add `Finder.app` when running `establishIconSet`
- The automatic re-applying of custom app icon after app updates
- Opening a theme will automatically import it into IconChamp 
- The report a bug button will 404 since it links to a private repo
